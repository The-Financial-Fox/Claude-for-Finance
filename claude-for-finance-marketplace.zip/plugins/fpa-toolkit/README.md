# FP&A Toolkit

FP&A workflows for a finance department, covering monthly reporting, forecasting, budgeting, and analytical deep-dives, all working from files you upload or paste, with no external data connections required. Deliverables are produced as Excel workbooks.

## Components

**Skills**

*Reporting & forecasting*
- `monthly-variance-report`, Compare budget vs. actual (or actual vs. prior period), decompose material variances into drivers, and produce a variance waterfall with written commentary.
- `rolling-forecast-builder`, Roll a forecast forward from actuals plus assumptions, producing base/upside/downside scenarios with live formulas.
- `annual-budget-builder`, Build a bottom-up annual budget from historical actuals plus department assumptions, consolidated into a company P&L.
- `cash-flow-forecast`, Build a weekly or monthly cash flow forecast from bank, AR, and AP data, with runway and minimum-cash flagging.
- `board-deck-narrative`, Turn financial results into board- or executive-ready written commentary grounded in driver analysis.

*Planning & modeling*
- `headcount-cost-planning`, Model a fully-loaded headcount cost plan from current roster data plus a hiring/attrition plan.
- `capex-investment-analysis`, Build an NPV/IRR/payback business case for a capital investment, with sensitivity analysis.
- `scenario-sensitivity-modeling`, Add tornado, two-way, or Monte Carlo sensitivity analysis to an existing financial model.

*Analytical deep-dives*
- `unit-economics-analysis`, Calculate CAC, LTV, LTV:CAC, and CAC payback from real cohort retention data for a subscription business.
- `working-capital-analysis`, Calculate DSO/DPO/DIO and the cash conversion cycle, with driver attribution and cash impact.

**Agents**

*Used automatically across skills*
- `data-validator`, Checks any uploaded financial data file for structural issues, nulls, duplicates, period gaps, unit mismatches, and outliers before analysis runs.
- `driver-decomposition`, Breaks a variance or trend into its component drivers (price/volume/mix, rate/volume, FX, timing) with a reconciled bridge.
- `formula-auditor`, Audits a finished Excel workbook for hardcoded values, broken references, circular references, and inconsistent formulas before delivery.

*Used where a skill calls for them*
- `scenario-modeler`, Runs one-way sensitivity (tornado), two-way data tables, or Monte Carlo simulation on a financial model.
- `cohort-analyzer`, Groups customer data into cohorts and builds retention/revenue curves for unit economics analysis.
- `benchmark-researcher`, Looks up external industry benchmarks to put a metric in context, using live web search.
- `narrative-editor`, Tightens draft financial commentary into direct, executive-ready language without changing its substance.

## Setup

No environment variables or external connections required for the core workflows. This plugin works entirely from files you upload directly in the conversation. The `benchmark-researcher` agent uses web search for external context when a skill calls on it; no separate setup is needed for that either.

## Usage

Just describe what you need in plain language and the relevant skill will trigger, for example:
- "Here's this month's budget and actuals, build the variance report."
- "Use these six months of actuals to roll the forecast forward through year end."
- "Build next year's budget from these department inputs."
- "Build a 13-week cash flow forecast from our bank and AR/AP data."
- "Model the cost of our hiring plan for next year."
- "Should we invest in this new equipment, build the business case."
- "Run a sensitivity analysis on this forecast."
- "What's our CAC, LTV, and payback period?"
- "Analyze our working capital trend."
- "Draft the board narrative for this quarter's results."

Each skill validates your data first, decomposes material variances or trends into real drivers, and delivers an Excel workbook you can open directly. Skills are designed to chain: for example, a headcount cost plan can feed directly into the annual budget, and any finished model can have sensitivity analysis layered on top of it afterward.

## Customization

This plugin is file-based by design and has no external tool references beyond web search for benchmarking, so there's nothing to customize per-organization, it works the same way out of the box for any finance team.
