---
name: working-capital-analysis
description: >
  This skill should be used when the user asks to "analyze our working
  capital", "what's our cash conversion cycle", "run a DSO/DPO/DIO
  analysis", "why is working capital tying up cash", or provides AR, AP,
  and inventory data and wants working capital efficiency analyzed.
  Produces an Excel workbook with trend, driver breakdown, and cash impact.
metadata:
  version: "0.2.0"
---

# Working Capital Analysis

Calculate DSO, DPO, DIO, and the cash conversion cycle over time, identify what's driving any deterioration or improvement, and quantify the cash impact, delivered as an Excel workbook.

## Workflow

1. **Validate the input data.** Run the `data-validator` agent on the AR aging, AP aging, and inventory data before analysis. Working capital metrics are especially sensitive to period-end cutoff issues, check specifically that the data-validator has confirmed consistent period-end dates across AR, AP, and inventory files.

2. **Calculate the core metrics** for each period in the analysis window:
   - **DSO** (Days Sales Outstanding): AR balance relative to revenue, reflecting how quickly customers pay.
   - **DPO** (Days Payable Outstanding): AP balance relative to cost of goods sold or purchases, reflecting how quickly the company pays suppliers.
   - **DIO** (Days Inventory Outstanding), if applicable: inventory balance relative to cost of goods sold, reflecting how long inventory sits before sale. Skip for service businesses with no inventory.
   - **Cash Conversion Cycle**: DSO + DIO - DPO, the net days cash is tied up in the operating cycle.

3. **Decompose the trend.** Run the `driver-decomposition` agent on any material period-over-period change in the cash conversion cycle to determine which of DSO, DPO, or DIO drove it, rather than presenting the combined metric's movement without attribution.

4. **Quantify the cash impact.** Translate a change in any of the component metrics into a dollar cash impact (e.g., "a 5-day increase in DSO tied up approximately $X in additional working capital at current revenue run-rate"), since days-outstanding metrics alone don't convey the size of the cash effect to a non-finance reader.

5. **Build the Excel workbook.** Before creating the file, load the xlsx skill for formatting and construction guidance. Structure the workbook as:
   - **Summary tab**: DSO/DPO/DIO/CCC trend over the analysis window as both a table and a trend chart, with the cash impact from step 4 called out.
   - **Detail tab**: the underlying AR/AP/inventory balances and revenue/COGS figures the ratios were calculated from.
   - **Driver tab**: the decomposition from step 3 for any material period-over-period change.

6. **Flag deteriorating trends.** If the cash conversion cycle has been lengthening (tying up more cash) over the analysis window, flag this prominently rather than only presenting it as a neutral trend line, and note which component is most responsible so the user knows where to focus.

## Notes

- Use a consistent revenue/COGS denominator basis (e.g., trailing-twelve-month vs. single-period) across all periods being compared, mixing bases will distort the trend.
- If the business has highly seasonal revenue or inventory patterns, note this and consider whether year-over-year (same period) comparison is more meaningful than sequential period comparison, seasonal working capital swings can look like a structural trend if compared sequentially.
- If the user wants to know how their cash conversion cycle compares to sector norms, the `benchmark-researcher` agent can pull external context, but keep the internal trend analysis as the primary deliverable.
