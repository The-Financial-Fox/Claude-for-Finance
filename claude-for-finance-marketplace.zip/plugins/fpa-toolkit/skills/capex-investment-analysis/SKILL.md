---
name: capex-investment-analysis
description: >
  This skill should be used when the user asks to "build an ROI analysis",
  "should we invest in this project", "what's the NPV of this capex", "build
  a business case for this investment", or provides projected costs and
  benefits of a capital project and wants a financial justification.
  Produces an Excel workbook with NPV, IRR, payback, and sensitivity.
metadata:
  version: "0.2.0"
---

# Capex Investment Analysis

Build a capital investment business case: NPV, IRR, payback period, and sensitivity to key assumptions, delivered as an Excel workbook.

## Workflow

1. **Validate supporting data.** If the projection is grounded in historical cost or revenue data, run the `data-validator` agent on it before building the projection.

2. **Gather the core inputs.** Confirm (or ask for, if not provided): the initial investment amount and timing, the projected incremental cash flows over the project's life (revenue gains and/or cost savings, net of any incremental operating cost), the project life, and the discount rate (WACC or hurdle rate). Never assume a discount rate, it materially changes the answer and should come from the user or the finance team's standard rate.

3. **Calculate core metrics.** NPV of the projected incremental cash flows at the given discount rate, IRR, simple and discounted payback period, and profitability index (NPV / initial investment).

4. **Run sensitivity.** Run the `scenario-modeler` agent to produce a one-way sensitivity (tornado) ranking which assumptions (discount rate, revenue ramp timing, cost overrun, useful life) move NPV the most, and a two-way table on the two most impactful assumptions if they plausibly interact.

5. **State the recommendation honestly.** If NPV is positive and IRR clears the hurdle rate under the base case, say so, but lead with how sensitive that conclusion is (from step 4) rather than presenting a single point estimate as if it were certain.

6. **Build the Excel workbook.** Before creating the file, load the xlsx skill for formatting and construction guidance. Structure the workbook as:
   - **Summary tab**: headline NPV, IRR, payback, profitability index, and a one-line recommendation with its key caveat.
   - **Cash Flow Detail tab**: year-by-year (or period-by-period) projected cash flows feeding the NPV/IRR calculation via live formulas.
   - **Sensitivity tab**: the tornado ranking and two-way table from step 4.
   - **Assumptions tab**: every input (discount rate, project life, ramp timing, cost assumptions) as editable cells.

7. **Audit before delivering.** Run the `formula-auditor` agent to confirm NPV/IRR formulas correctly reference the Assumptions tab and Cash Flow Detail tab rather than containing hardcoded intermediate values.

## Notes

- If the "do nothing" alternative has its own cost (e.g., a system that will fail without replacement, lost business without the investment), model that as the comparison baseline rather than comparing the investment against a flat zero, an investment that merely avoids a cost still needs to be evaluated against what happens without it.
- Terminal value or residual asset value at the end of the project life should be included explicitly as a labeled cash flow, not folded silently into the final year's operating cash flow.
- If multiple mutually exclusive investment options are being compared, present them side by side on the Summary tab using the same metrics and discount rate so they're genuinely comparable.
