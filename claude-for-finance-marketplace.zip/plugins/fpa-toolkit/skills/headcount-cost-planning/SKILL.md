---
name: headcount-cost-planning
description: >
  This skill should be used when the user asks to "build a headcount plan",
  "model our hiring costs", "what does adding this headcount cost us", or
  provides current roster data plus a hiring/attrition plan and wants a
  fully-loaded cost model. Produces an Excel workbook with headcount and
  cost by month, tied to a hiring plan.
metadata:
  version: "0.2.0"
---

# Headcount Cost Planning

Build a fully-loaded headcount cost model from current roster data and a hiring/attrition plan, delivered as an Excel workbook with headcount and cost projected by month.

## Workflow

1. **Validate the input data.** Run the `data-validator` agent on the roster/headcount file before building the model.

2. **Establish current state.** Summarize current headcount and base compensation by department, level, and location (location matters if pay bands or benefits load differ by geography).

3. **Apply a fully-loaded cost multiplier.** Fully-loaded cost includes base pay plus benefits, payroll taxes, and any other standard loading (equity expense, if the user wants it included). If the user hasn't provided a loading factor, ask rather than assuming an industry-generic multiplier, and state clearly whatever figure is used.

4. **Model the hiring/attrition plan.** Project headcount changes by month: planned new hires (with start-date and ramp assumptions, since a new hire's first 1-3 months rarely land at full productivity or full run-rate cost if pro-rated), planned attrition, and backfills. Keep hire/attrition timing as editable assumption inputs, not hardcoded into the projection.

5. **Decompose cost changes.** Run the `driver-decomposition` agent on period-over-period headcount cost changes to separate volume (net new heads) from rate (raises, promotions, mix shift toward more senior/expensive roles) effects, so the "why did headcount cost go up" question has a real answer beyond the total.

6. **Build the Excel workbook.** Before creating the file, load the xlsx skill for formatting and construction guidance. Structure the workbook as:
   - **Summary tab**: total headcount and fully-loaded cost by month, split by department.
   - **Roster tab**: current-state detail by employee or role (whichever granularity the source data supports).
   - **Hiring Plan tab**: editable inputs for planned hires, attrition, and timing, feeding the Summary tab via live formulas.
   - **Assumptions tab**: loading factor, ramp assumptions, and any comp inflation assumptions, all editable.

7. **Sanity-check against benchmarks (optional).** If the user wants to know whether the resulting cost-per-head or span-of-control looks typical for their sector and stage, run the `benchmark-researcher` agent to pull external context rather than asserting a judgment from internal data alone.

## Notes

- If comp data is sensitive, confirm with the user whether individual-level detail should appear in the deliverable or whether department/level aggregates are sufficient.
- Ramp assumptions matter more than they first appear, a plan that assumes every new hire is instantly at full cost and full productivity will understate near-term cash needs and overstate near-term output; state the ramp assumption used.
- If this headcount build is feeding into `annual-budget-builder`, structure the Summary tab's monthly cost line so it can be pulled directly into that budget's department tabs without reformatting.
