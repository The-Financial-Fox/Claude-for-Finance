---
name: rolling-forecast-builder
description: >
  This skill should be used when the user asks to "update the forecast",
  "build a rolling forecast", "reforecast the year", "roll the forecast
  forward", or provides actuals plus assumptions and wants an updated
  forward-looking forecast. Produces an Excel workbook with base, upside,
  and downside scenarios.
metadata:
  version: "0.2.0"
---

# Rolling Forecast Builder

Take actuals through the latest closed period plus a set of assumptions, and produce an updated rolling forecast for the remaining periods as an Excel workbook with multiple scenarios.

## Workflow

1. **Validate the input data.** Run the `data-validator` agent on the actuals file(s) before building the forecast. Pay particular attention to period coverage gaps, since a rolling forecast depends on clean, contiguous historical periods. Do not proceed on a "Do not proceed" verdict without resolving the blocking issues with the user.

2. **Establish the baseline.** Identify the last actual closed period and the remaining periods that need to be forecast. If the user hasn't specified the forecast horizon (e.g., "rest of fiscal year," "next 12 months"), ask before proceeding.

3. **Understand recent trend drivers.** Run the `driver-decomposition` agent on the trailing 3-6 months of actuals for key lines (revenue, major cost categories) to understand what's been driving recent performance. Use this to sanity-check the assumptions provided by the user rather than forecasting on trend alone.

4. **Gather or confirm assumptions.** If the user has provided assumptions (growth rates, headcount plans, price changes, seasonality), use them. If assumptions are missing for a line that needs forecasting, ask the user rather than inventing a number, state clearly which lines are assumption-driven versus trend-extrapolated.

5. **Build three scenarios**, unless the user asks for a single scenario:
   - **Base case**: the assumptions as given.
   - **Upside case**: assumptions flexed favorably (default: key growth/rate assumptions improved by a magnitude consistent with recent historical volatility, unless the user specifies their own upside assumptions).
   - **Downside case**: assumptions flexed unfavorably, same logic in reverse.
   State explicitly how the upside/downside cases were derived so they're not mistaken for user-provided inputs.

6. **Build the Excel workbook.** Before creating the file, load the xlsx skill for formatting and construction guidance. Structure the workbook as:
   - **Summary tab**: actuals + base case forecast by period, key totals (revenue, gross margin, opex, EBITDA or equivalent), with upside/downside shown as a range or shaded band.
   - **Base / Upside / Downside tabs**: full line-item detail for each scenario, actuals clearly distinguished from forecast periods (e.g., shading or a divider column).
   - **Assumptions tab**: every assumption used, labeled as user-provided vs. system-derived, editable as raw input cells that flow into the forecast formulas (not hardcoded/pasted values) so the user can adjust and see the forecast update.
   - Use consistent number formatting and freeze header rows/columns as needed for readability across many periods.

7. **Flag reasonableness issues.** If the base case forecast implies a trend sharply inconsistent with recent actuals (e.g., a sudden margin expansion with no corresponding assumption change), flag this to the user rather than silently presenting it.

## Notes

- Keep forecast formulas live in the workbook (assumptions tab feeds calculation, not just static output values) so the deliverable is genuinely reusable, not a one-time snapshot.
- If the user only wants a single scenario, skip step 5's upside/downside construction but keep the Assumptions tab and live formulas.
- If the user wants a rigorous view of outcome likelihood rather than three fixed scenarios (e.g., "what's the probability we miss plan"), the `scenario-sensitivity-modeling` skill can run a Monte Carlo simulation on top of this workbook once it's built.
