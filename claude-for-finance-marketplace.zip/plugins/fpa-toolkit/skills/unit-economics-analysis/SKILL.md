---
name: unit-economics-analysis
description: >
  This skill should be used when the user asks to "analyze our unit
  economics", "what's our CAC and LTV", "run a cohort retention analysis",
  "what's our CAC payback period", or provides customer/revenue/cost data
  for a subscription or recurring-revenue business and wants per-customer
  economics analyzed. Produces an Excel workbook with headline unit
  economics and supporting cohort detail.
metadata:
  version: "0.2.0"
---

# Unit Economics Analysis

Calculate CAC, LTV, LTV:CAC, and CAC payback period for a subscription or recurring-revenue business, grounded in real cohort retention data rather than blended averages, delivered as an Excel workbook.

## Workflow

1. **Validate the input data.** Run the `data-validator` agent on the customer, revenue, and sales/marketing cost data before analysis.

2. **Build cohort retention.** Run the `cohort-analyzer` agent on the customer-level data to produce retention and revenue curves by signup cohort. Unit economics calculated from a blended average customer, rather than actual retention curves, systematically misstate LTV, don't skip this step even for a quick request.

3. **Calculate CAC.** Fully-loaded sales and marketing cost for the period divided by new customers acquired in that period. State clearly what's included in "fully-loaded" (e.g., whether it includes sales/marketing salaries and overhead, or spend only) and keep it consistent with how the user or their finance team defines it if they've specified.

4. **Calculate LTV.** Derive LTV from the cohort retention/revenue curve (not from a flat average lifespan assumption), applying gross margin so LTV reflects contribution, not gross revenue. If retention data is too immature to project a full lifetime curve, extrapolate conservatively from the observed curve and state that it's an extrapolation.

5. **Calculate CAC payback period.** Months of gross-margin-adjusted revenue from an average new customer needed to recover CAC.

6. **Explain trend, if requested.** If the user wants to know why these metrics have moved, run the `driver-decomposition` agent on the period-over-period change (e.g., is a worsening LTV:CAC driven by rising CAC, declining retention, or margin compression).

7. **Build the Excel workbook.** Before creating the file, load the xlsx skill for formatting and construction guidance. Structure the workbook as:
   - **Summary tab**: headline CAC, LTV, LTV:CAC, and payback period, with trend over recent periods.
   - **Cohort tab**: the retention and revenue curves by cohort from step 2.
   - **Assumptions tab**: gross margin, cost inclusion definition, and any extrapolation assumptions used, all stated explicitly.

8. **Add external context, if wanted.** If the user wants to know how these metrics compare to their sector, run the `benchmark-researcher` agent rather than asserting a judgment about what's "good."

## Notes

- Never blend cohorts of very different ages into a single retention/LTV number, use the cohort-analyzer agent's same-age comparisons so newer and older customers aren't averaged together in a way that hides a real trend.
- If CAC and revenue data don't share a clean common time boundary (e.g., marketing spend attributed monthly but revenue recognized differently), flag the mismatch rather than dividing mismatched periods against each other.
- State every definitional choice (what counts as "acquisition cost," how churn is defined, whether LTV is gross-margin or gross-revenue based) since unit economics benchmarks are only comparable when definitions match.
