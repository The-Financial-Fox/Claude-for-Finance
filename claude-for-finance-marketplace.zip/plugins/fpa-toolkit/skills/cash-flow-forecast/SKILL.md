---
name: cash-flow-forecast
description: >
  This skill should be used when the user asks to "build a cash flow
  forecast", "build a 13-week cash flow", "how much runway do we have",
  "forecast our cash position", or provides bank balances plus AR/AP data
  and wants a forward view of cash. Produces an Excel workbook with a
  weekly or monthly cash forecast, runway, and minimum-cash flagging.
metadata:
  version: "0.2.0"
---

# Cash Flow Forecast

Build a direct-method cash flow forecast (weekly or monthly) from current cash position, AR/AP data, and planned disbursements, delivered as an Excel workbook that flags runway and any period where cash falls below a minimum threshold.

## Workflow

1. **Validate the input data.** Run the `data-validator` agent on the bank balance, AR aging, AP aging, and any planned disbursement files before building the forecast.

2. **Determine the cadence.** A 13-week forecast is standard for active liquidity management; a monthly cadence suits a longer annual view. If the user hasn't specified, ask which fits their purpose rather than assuming.

3. **Build inflows.** Project cash collections from the AR aging schedule using historical collection patterns (or a stated DSO/collection-rate assumption if aging data isn't granular enough), plus any other known cash inflows (new financing, asset sales).

4. **Build outflows.** Project AP disbursements from the AP aging schedule and payment terms, plus payroll, recurring operating expenses, planned capex, and debt service. Keep each outflow category as its own line so the forecast is auditable, not a single blended "expenses" number.

5. **Normalize the baseline.** Run the `driver-decomposition` agent on any large swing in recent actual cash flow to determine whether it's recurring or one-time before it influences the forward projection.

6. **Layer in scenarios.** Run the `scenario-modeler` agent to produce best/base/worst-case runway outcomes (or a full distribution, if the user wants likelihood rather than fixed scenarios) by flexing the most uncertain assumptions, typically collection speed and discretionary spend timing.

7. **Build the Excel workbook.** Before creating the file, load the xlsx skill for formatting and construction guidance. Structure the workbook as:
   - **Summary tab**: the cash position curve over the forecast horizon, runway (weeks/months until a stated minimum cash threshold is breached, if ever), and the scenario range from step 6.
   - **Detail tab**: full inflow/outflow line detail by period, actuals clearly distinguished from projected periods.
   - **Assumptions tab**: collection rate, payment timing, and any other key assumptions as editable inputs.

8. **Flag threshold breaches.** If any period in the base case (or worse) shows cash falling below the user's stated minimum cash threshold (or below zero, if none was stated), flag it explicitly at the top of the Summary tab rather than leaving it to be noticed on the chart.

## Notes

- If the user hasn't stated a minimum cash threshold (e.g., a covenant minimum or an internal buffer target), ask before finalizing the runway flagging, don't silently default to zero.
- Direct-method forecasts degrade quickly if AR/AP aging data is stale, confirm the "as of" date on those files during validation and note it prominently in the deliverable.
- If the forecast needs to extend past what AR/AP aging data can reliably project (typically beyond 90-120 days), note that the further-out periods rely more heavily on trend/assumption than on aging detail, and label them accordingly.
