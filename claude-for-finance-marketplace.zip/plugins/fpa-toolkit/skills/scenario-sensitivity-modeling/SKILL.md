---
name: scenario-sensitivity-modeling
description: >
  This skill should be used when the user asks to "run a sensitivity
  analysis", "build a tornado chart", "what's our exposure to this
  assumption", "run a Monte Carlo simulation", or has an existing financial
  model (forecast, budget, investment case) and wants its sensitivity to
  uncertain assumptions quantified rather than relying on fixed scenarios
  alone. Extends an existing Excel workbook with sensitivity and/or
  simulation tabs.
metadata:
  version: "0.2.0"
---

# Scenario & Sensitivity Modeling

Add rigorous sensitivity analysis, one-way tornado, two-way tables, and/or Monte Carlo simulation, to an existing financial model, so the user knows which assumptions matter and how much risk the output actually carries.

## Workflow

1. **Confirm the model is sound before stress-testing it.** If there's any doubt the underlying workbook's formulas are genuinely live and internally consistent, run the `formula-auditor` agent first. Sensitivity analysis on a model with hardcoded values or broken formulas will produce misleading results.

2. **Identify the uncertain assumptions.** List the inputs that are genuinely uncertain (as opposed to fixed facts), and confirm plausible ranges (for tornado/two-way) or distribution shapes (for Monte Carlo) with the user if not already stated. Don't invent ranges without grounding them in stated volatility, historical data, or explicit user input.

3. **Run the analysis.** Use the `scenario-modeler` agent to perform:
   - **One-way sensitivity (tornado)**, when the question is which assumptions matter most.
   - **Two-way data table**, when two assumptions interact and the user wants to see the combined effect.
   - **Monte Carlo simulation**, when the question is about the range and likelihood of outcomes, not just which assumption matters most.
   Run more than one method when the user's question calls for it, they answer different questions and aren't interchangeable.

4. **Reconcile the base case.** Confirm the sensitivity/simulation run reproduces the model's actual base-case output exactly before presenting results, a mismatch means the flex logic doesn't match the model's real formulas.

5. **Extend the Excel workbook.** Before adding tabs, load the xlsx skill for formatting and construction guidance. Add (as applicable):
   - **Tornado tab**: assumptions ranked by output impact, formatted for a tornado chart.
   - **Two-Way Sensitivity tab**: the output grid across the two flexed assumptions.
   - **Monte Carlo tab**: the distribution's summary statistics, key percentiles, and a chart of the outcome distribution.
   Keep these as new tabs in the existing workbook rather than a separate file, so the sensitivity results stay attached to the model they describe.

6. **Summarize what matters.** Close with a plain-language summary of the 2-3 assumptions the output is most sensitive to, and, for Monte Carlo, the probability of any threshold outcome the user cares about (e.g., "18% probability NPV is negative").

## Notes

- State every flex range or distribution parameter used explicitly on the relevant tab, not just in the summary, so the analysis is auditable later without re-asking the assumptions.
- A tornado ranking is only as good as the ranges behind it, if the user provides no guidance on plausible ranges, use historical volatility from the model's own underlying data where available rather than an arbitrary percentage.
- This skill assumes an existing model to extend; if no model exists yet, build the underlying analysis first (e.g., via `capex-investment-analysis`, `cash-flow-forecast`, or `annual-budget-builder`) before layering sensitivity on top of it.
