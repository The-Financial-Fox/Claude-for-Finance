---
name: board-deck-narrative
description: >
  This skill should be used when the user asks to "write the board narrative",
  "prepare the board financial summary", "draft exec commentary for the
  board deck", or has financial results/forecast data and needs it turned
  into board- or executive-ready written summary language. Produces an
  Excel workbook with a KPI summary and narrative commentary.
metadata:
  version: "0.2.0"
---

# Board Deck Narrative

Turn financial results (actuals, variance, and/or forecast data) into board- or executive-ready narrative commentary, delivered as an Excel workbook that a board deck can be built from.

## Workflow

1. **Validate the input data.** Run the `data-validator` agent on any uploaded financial data before drafting narrative from it. Board-facing commentary built on bad data is high-stakes, do not proceed past a "Do not proceed" verdict without resolving it.

2. **Identify the story, not just the numbers.** Determine the 3-5 things a board member most needs to understand this period: e.g., did the company hit plan, what's the biggest risk or opportunity, what changed since last update. If this skill is used alongside `monthly-variance-report` or `rolling-forecast-builder` output, reuse that analysis rather than re-deriving it.

3. **Decompose the headline movements.** For the 1-3 largest year-over-year, quarter-over-quarter, or budget-vs-actual movements that anchor the narrative, run the `driver-decomposition` agent so the commentary is grounded in actual drivers rather than generic language.

4. **Write the narrative.** Draft commentary at two levels:
   - **Headline summary** (2-4 sentences): the single most important takeaway a board member should walk away with.
   - **Section commentary** (1 short paragraph per key metric or topic): revenue, margin, cash, and any other board-relevant area, each grounded in the driver decomposition from step 3.
   Use plain, direct business language. Avoid hedging language and avoid simply narrating the table ("revenue was $X, up from $Y"), say what it means and why it matters.

5. **Edit for concision.** Run the `narrative-editor` agent on the draft from step 4 to cut restated-numbers filler, unnecessary hedging, and jargon before it goes into the workbook. This is a distinct pass from drafting, don't skip it just because the initial draft reads reasonably.

6. **Build the Excel workbook.** Before creating the file, load the xlsx skill for formatting and construction guidance. Structure the workbook as:
   - **KPI Summary tab**: the key metrics in a clean at-a-glance table/chart format (current period, prior period, budget, variance).
   - **Narrative tab**: the headline summary at the top, followed by section commentary, formatted with clear headers so it can be copied into slides or read standalone.
   - **Supporting Detail tab**: the underlying data and driver breakdowns the narrative draws from, so any number in the narrative can be traced back to its source.

7. **Keep it board-length.** Board audiences want the takeaway, not the full analysis. If the narrative tab is running long, move supporting detail to the Supporting Detail tab and keep the Narrative tab focused on conclusions.

## Notes

- Never state a causal driver in the narrative that wasn't confirmed by the driver-decomposition agent or explicitly provided by the user, flag speculative explanations as speculative rather than presenting them as fact.
- If the user wants this narrative to accompany a live PowerPoint board deck rather than stand alone, note that the pptx skill is available for that separate deliverable, but keep this skill's output in Excel per the plugin's default.
