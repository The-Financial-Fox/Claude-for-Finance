---
name: annual-budget-builder
description: >
  This skill should be used when the user asks to "build next year's budget",
  "put together the annual budget", "build a bottom-up budget for next year",
  or provides historical actuals plus department targets/assumptions and
  wants a full annual budget built from the ground up. Produces an Excel
  workbook with department-level budget builds and a consolidated company P&L.
metadata:
  version: "0.2.0"
---

# Annual Budget Builder

Build a bottom-up annual budget from historical actuals plus department-level assumptions, consolidated into a company-wide P&L, delivered as an Excel workbook with live formulas.

## Workflow

1. **Validate the input data.** Run the `data-validator` agent on the historical actuals that will anchor the budget baseline. Do not proceed past a "Do not proceed" verdict without resolving it with the user.

2. **Establish the baseline.** Use the trailing 12 months of actuals as the starting point for each line. Run the `driver-decomposition` agent on any line with a notable one-time item or unusual run-rate, so the baseline reflects normalized run-rate, not a distorted trailing average.

3. **Gather department-level assumptions.** For each department or cost center, collect (or ask for, if not provided): headcount plans, revenue or growth targets, planned cost changes, and any known one-time items for the budget year. If headcount-driven costs are a major component, note that the `headcount-cost-planning` skill can produce a detailed headcount cost build to feed directly into this budget rather than estimating headcount cost inline.

4. **Build department budgets bottom-up.** For each department, project every line for each month of the budget year from the baseline plus that department's assumptions, keeping assumption inputs as separate, editable cells rather than baked into the projection formulas.

5. **Consolidate to the company P&L.** Roll all department budgets up into a single consolidated monthly P&L, and reconcile the total to the sum of department detail (no plugs or manual adjustments that don't trace to a department line).

6. **Tie out against context.** Compare the consolidated budget to the prior year actual and, if one exists, the current in-flight forecast. Flag any line where the budget implies a change sharply inconsistent with recent trend and no assumption explains why.

7. **Build the Excel workbook.** Before creating the file, load the xlsx skill for formatting and construction guidance. Structure the workbook as:
   - **Company Summary tab**: consolidated monthly P&L for the budget year, with prior-year actual and current forecast shown alongside for comparison.
   - **Department tabs**: one per department, full line-item detail with assumption inputs clearly separated from computed rows.
   - **Assumptions tab**: every department's key assumptions in one place, editable as raw inputs that flow into the department tabs.
   - **Consolidation tab**: the roll-up logic from department tabs to the Company Summary tab, so the trace from any company-level number back to its department source is visible.

8. **Audit before delivering.** Run the `formula-auditor` agent on the finished workbook to confirm department budgets are genuinely formula-driven from the Assumptions tab (not hardcoded), and that the consolidation ties out without a manual plug.

## Notes

- If departments use inconsistent account taxonomies and the data-validator flagged this, resolve the mapping before building department tabs, don't guess at correspondence between departments.
- If the user wants the budget itself stress-tested against uncertainty (not just built), the `scenario-sensitivity-modeling` skill can run on top of this workbook once it exists.
- Keep every department's assumptions as raw, editable inputs; a budget that can't be updated by changing an assumption cell isn't meaningfully different from a static PDF.
