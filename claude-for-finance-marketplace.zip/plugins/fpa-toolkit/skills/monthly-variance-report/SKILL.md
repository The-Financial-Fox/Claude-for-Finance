---
name: monthly-variance-report
description: >
  This skill should be used when the user asks to "build a variance report",
  "compare budget to actual", "explain the budget vs actual gap", "do a
  monthly variance analysis", or uploads actuals and budget data and wants
  to understand where and why results differed from plan. Produces an Excel
  workbook with a variance waterfall, driver breakdown, and written commentary.
metadata:
  version: "0.2.0"
---

# Monthly Variance Report

Build a budget-vs-actual (or actual-vs-prior-period) variance report as an Excel workbook, with drivers identified and commentary written in plain business language.

## Workflow

1. **Validate the input data.** Before building anything, run the `data-validator` agent on the uploaded actuals and budget files. Do not proceed to analysis if the agent returns a "Do not proceed" verdict, report the blocking issues to the user and ask how they want to resolve them.

2. **Compute variances.** For each line item (and at the total level), calculate:
   - Actual minus Budget (or prior period), in dollars
   - Variance as a percent of budget
   - Flag whether the variance is favorable or unfavorable given the nature of the line (e.g., higher revenue is favorable, higher expense is unfavorable)

3. **Decompose material variances.** For any variance above a materiality threshold (default: greater of $50,000 or 5% of the line's budget value, unless the user specifies otherwise), run the `driver-decomposition` agent to break the variance into its component drivers. Do not decompose immaterial variances, list them but skip the driver breakdown to keep the report focused.

4. **Write commentary.** For each material variance, write 1-3 sentences of plain-language commentary based on the driver breakdown, what happened, why, and whether it's a one-time or recurring effect. Avoid restating the numbers that are already visible in the table; explain what they mean.

5. **Build the Excel workbook.** Before creating the file, load the xlsx skill for formatting and construction guidance. Structure the workbook as:
   - **Summary tab**: total-level variance waterfall (starting value -> each material driver -> ending value) as both a table and a waterfall chart.
   - **Detail tab**: full line-item variance table (line, budget, actual, $ variance, % variance, favorable/unfavorable flag), sorted by absolute variance descending.
   - **Commentary tab**: one row per material variance line, with the written commentary next to it.
   - Use consistent number formatting (thousands separators, parentheses for unfavorable/negative values) and freeze the header row on each tab.

6. **Review before delivering.** Confirm the driver breakdowns reconcile to the total variance (the driver-decomposition agent should have already checked this, but re-verify at the report level: sum of all line-item variances should equal the total variance shown on the Summary tab).

## Notes

- If the user hasn't specified a materiality threshold, use the default above and state it in the report so the reader knows why some variances weren't decomposed.
- If budget and actual use different account taxonomies and the data-validator flagged this, resolve the mapping with the user before computing variances, do not guess at account correspondence.
- If prior-period data is provided instead of budget, run the same workflow using prior period as the comparison baseline, and label the report "Actual vs. Prior Period" instead of "Actual vs. Budget."
- Before delivering, run the `formula-auditor` agent on the finished workbook to confirm the waterfall and driver figures are formula-driven from the Detail tab rather than pasted values.
