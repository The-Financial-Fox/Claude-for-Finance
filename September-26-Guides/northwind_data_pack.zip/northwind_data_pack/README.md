# Northwind Systems sample data pack

Fictional B2B software, services and hardware company. Four entities (NW-US, NW-EMEA,
NW-APAC, NW-LATAM), monthly data from January 2023 to September 2025, reporting date
30 September 2025. All figures are invented and internally consistent enough to be
worked across files (the same customers appear in revenue, AR and pipeline).

Some files contain deliberate problems (duplicates, negative amounts, missing coding,
outliers, an intercompany mismatch) so the data quality and controls prompts have
something real to find. Do not fix them before you start.

## Files

- **ap_aging.csv** (320 rows): bill_id, supplier, category, bill_date, due_date, payment_terms, amount, entity ...

- **ar_aging.csv** (417 rows): invoice_id, customer_id, customer_name, invoice_date, due_date, payment_terms, amount, days_past_due ...

- **ar_payment_history.csv** (1,568 rows): invoice_id, customer_id, customer_name, due_date, paid_date, amount, delay_days

- **bank_transactions.csv** (1,057 rows): date, account, description, counterparty, inflow, outflow, balance

- **capex_projects.csv** (28 rows): project_id, project_name, category, entity, budget, spend_to_date, phase, start_date ...

- **customers.csv** (180 rows): customer_id, customer_name, segment, region, industry, plan, mrr, contract_start ...

- **entity_trial_balance.csv** (48 rows): entity, period, account_code, account_name, account_type, debit, credit, currency ...

- **expense_transactions.csv** (1,609 rows): txn_id, date, employee_id, category, vendor, amount, currency, cost_center ...

- **fx_rates.csv** (132 rows): month, currency, closing_rate, average_rate, base_currency

- **headcount.csv** (278 rows): employee_id, department, level, entity, location, annual_salary, bonus_target_pct, start_date ...

- **inventory.csv** (120 rows): sku, product, location, units_on_hand, unit_cost, inventory_value, reorder_point, units_sold_last_90d ...

- **marketing_spend.csv** (198 rows): month, channel, spend, leads, mqls, opportunities, closed_won_value

- **monthly_pl_actual_budget.csv** (1,056 rows): month, entity, department, account_group, account, actual, budget, prior_year

- **pipeline_deals.csv** (420 rows): deal_id, account, stage, probability_pct, amount, created_date, expected_close_date, owner ...

- **price_volume_mix.csv** (165 rows): month, product, units, list_price, realized_price, discount_pct, revenue

- **revenue_transactions.csv** (5,637 rows): invoice_id, invoice_date, customer_id, customer_name, product, region, quantity, unit_price ...
