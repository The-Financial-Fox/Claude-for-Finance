# Answers: every planted problem

Open only after you have tried.

## Consolidation (waldo_consolidation)

1. **NW-EMEA reports in thousands.** The pack says so on row 5 of each tab, in small text.
   Every EMEA figure must be multiplied by 1,000 before consolidating. Miss it and EMEA
   contributes roughly 0.1% of what it should. This is the expensive one.
2. **NW-APAC trial balance does not balance.** Total debits exceed total credits by
   41,350 SGD. The reported total line is wrong, not the individual accounts.
3. **NW-UK is on a different chart of accounts.** Claybourne Analytics was acquired on
   1 July 2025 and still uses its own nominal codes. The mapping file says "MAPPING NOT
   YET DEFINED". The correct answer is to flag it, not to guess a mapping.
4. **NW-LATAM contains August figures under a September heading.** The set/25 column
   repeats the ago/25 column exactly. Compare the two columns and it is obvious.
5. **Intercompany mismatch.** NW-US intercompany receivable is 1,845,200. NW-EMEA
   intercompany payable is 1,762,400. Gap of 82,800 that nobody has reconciled.
6. **Group consolidation has a hardcoded revenue override.** On the Consolidated P&L,
   the 4000 Revenue row does not use the SUM formula that every other row uses. It is a
   typed number, 3.1% above the sum of the entities, with the note "adj per group review".
   Also note NW-UK is included as a column of zeros.

## The model (cedric_model_audit/BeanStreet_model_v7.xlsx)

1. **Hardcode in a formula row.** P&L row 5 (Revenue), Year 3 column D, is typed as
   4,982,000 instead of carrying the growth formula. This is why "Year 4 looks wrong".
2. **Tax is calculated on EBITDA, not EBIT.** P&L row 14 references row 11 (EBITDA)
   rather than row 13 (EBIT), so tax is overstated.
3. **SUM range misses a row in the final year.** P&L row 15 (Net income) uses
   =SUM(x13:x14) for years 1 to 4 but just =F13 in Year 5, so Year 5 net income excludes tax.
4. **Sign error on depreciation in the balance sheet.** Fixed assets adds depreciation
   instead of deducting it, so fixed assets grow faster than capex.
5. **Opening cash points at the wrong assumption.** Cash flow opening cash in Year 1
   references Assumptions!B16 (Depreciation years, value 7) instead of B17 (Opening cash).
   The model literally opens with 7 dollars of cash.
6. **The balance sheet does not balance,** which is the visible symptom of 4 and 5 and is
   what the Checks tab has been reporting for months.

## CRM (catherine_crm)

Not a trap, but the point: the `probability_pct` field is the CRM's default by stage.
The stage history file lets you calculate the *actual* conversion rate between stages and
the real time spent in each. They disagree, and the difference is the whole value of the
exercise. P. Lindqvist's deals also move through stages materially slower than everyone
else's, which is visible only in stage_history.csv.
