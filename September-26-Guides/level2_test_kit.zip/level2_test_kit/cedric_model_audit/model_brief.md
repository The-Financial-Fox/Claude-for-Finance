# Bean Street Coffee: model brief

Bean Street runs 12 coffee shops and opens roughly 3 a year. This model was built by
someone who has since left. It is used for the bank covenant pack, so the numbers matter.

What the model is meant to support:
- How much cash do we need to fund the next 5 years of openings
- What happens to margin as we grow
- Whether we breach a 2.5x net debt to EBITDA covenant

Known complaints from the team:
- "The checks tab has been showing FALSE for months"
- "Year 4 revenue looks wrong but nobody can find why"
- "The cash number at the bottom does not match the bank"

Your job is to find every defect before you rebuild anything.
