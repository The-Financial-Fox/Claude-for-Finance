# Level 2 test kit

Harder material for the Level 2 Office Hours asks. Unlike the Level 1 pack, these are
real .xlsx files with genuinely different layouts, and the problems in them are the kind
that survive a quick look.

Reporting date is 30 September 2025 throughout.

## What is in here

**waldo_consolidation/** Five entity reporting packs, each built by a different team in a
different format, plus the group consolidation, an account mapping file and September FX
rates. At least six things in here are wrong or inconsistent. Some are obvious. At least
one will cost you a material misstatement if you miss it.

**cedric_model_audit/** `BeanStreet_model_v7.xlsx`, a five year operating model with live
formulas, built by someone who has left. Its checks tab has been showing FALSE for months.
There are six distinct defects. The brief explains what the model is used for.

**catherine_crm/** Deals, full stage history, activities and quarterly targets. The stage
history is what lets you calculate real velocity and conversion by stage and by owner,
rather than trusting the probability field.

**cedric_monthly_review/** P&L actual vs budget, revenue transactions, headcount, and the
house style guide the commentary has to follow.

**cedric_cash/** AR aging, AP aging, payment history and bank transactions for the
13 week forecast.

**valeria_plugin/fpa-toolkit/** A working plugin skeleton: two skills (one with a
reference file so you can see progressive disclosure), a reviewer subagent and a slash
command. Copy it, rename it, make it yours.

## Rules of the game

Do not fix anything before you start. The point is to find it.

`ANSWERS.md` lists every planted problem. Do not open it until you have had a go.
