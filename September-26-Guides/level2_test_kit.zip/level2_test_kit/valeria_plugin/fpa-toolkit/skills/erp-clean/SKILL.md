---
name: erp-clean
description: Clean and standardise a raw ERP or billing export into our standard analysis format. Use when given a raw export, a trial balance dump, or any file that needs normalising before analysis.
---

# ERP export cleaning

## Steps
1. Inventory first. Report rows, columns, period and currency before changing anything.
2. Standardise dates to ISO, account names to the group chart of accounts, currency to USD.
3. Flag rather than delete: duplicates, unmapped accounts, impossible values, wrong period.
4. Never silently drop a row. Every excluded row appears in the exclusions log.

## Output
- `clean_<source>_<period>.csv`
- `exclusions_<source>_<period>.csv` with a reason per row
- A three line summary: rows in, rows out, rows flagged.
