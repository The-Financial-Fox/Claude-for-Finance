---
name: variance-commentary
description: Write monthly budget vs actual variance commentary in our house style. Use when asked for variance commentary, month-end commentary, or to explain budget vs actual movements.
---

# Variance commentary

## Inputs
A P&L file with actual, budget and prior period columns by department.

## Rules
1. Explain only variances above 5% or 25k. Ignore the rest, and say so once.
2. Each variance gets four lines: the number, the driver, the action, the owner.
3. Never invent a driver. If the data does not explain it, write "Needs input from [owner]".
4. Plain English. No jargon. No preamble.

## Output
A markdown table ordered by absolute variance, then a short list of open questions.

## Reference
For the full department owner list and thresholds by cost centre, read `reference/owners.md`.
