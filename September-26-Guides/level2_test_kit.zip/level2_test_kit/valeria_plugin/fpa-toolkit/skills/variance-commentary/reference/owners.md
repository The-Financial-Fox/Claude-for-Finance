# Department owners and thresholds

| Department | Owner | Threshold |
|---|---|---|
| Sales | VP Sales | 25k |
| Marketing | CMO | 25k |
| Engineering | CTO | 50k |
| Customer Success | VP CS | 15k |
| Finance | CFO | 10k |
| Operations | COO | 25k |
