---
description: Run the full month-end sequence: clean, check, reconcile, commentary.
---

Run our month-end sequence on the files in the current folder.

1. Use the erp-clean skill on every raw export.
2. Run the month-end checks and produce the issues log.
3. Reconcile the sub-ledger to the P&L and report differences above 1%.
4. Use the variance-commentary skill on the cleaned P&L.
5. Stop and show me the issues log before writing any commentary.
