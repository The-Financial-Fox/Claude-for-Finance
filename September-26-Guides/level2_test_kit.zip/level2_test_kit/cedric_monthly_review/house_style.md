# Monthly review: house style

Structure, always this order:
1. Headline message, one sentence
2. KPI summary vs budget and vs last month
3. Revenue by business line
4. Margin bridge
5. Opex by department
6. Cash and working capital
7. Risks, decisions needed, asks

Commentary rules:
- Lead with the number, then the driver, then the action, then the owner.
- Explain variances above 5% or 25k. Ignore anything smaller.
- Never invent a reason. Write "Needs input from [owner]" instead.
- Maximum 3 bullets per chart. No jargon.

Tone: direct, no hedging, no preamble. The CFO reads the first line of each slide only.
